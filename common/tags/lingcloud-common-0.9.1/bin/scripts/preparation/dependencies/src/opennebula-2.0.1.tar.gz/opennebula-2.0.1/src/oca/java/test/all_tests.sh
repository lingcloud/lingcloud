#!/bin/bash

./test.sh ClusterTest
./test.sh HostTest
./test.sh ImageTest
./test.sh SessionTest
./test.sh UserTest
./test.sh VirtualMachineTest
./test.sh VirtualNetworkTest