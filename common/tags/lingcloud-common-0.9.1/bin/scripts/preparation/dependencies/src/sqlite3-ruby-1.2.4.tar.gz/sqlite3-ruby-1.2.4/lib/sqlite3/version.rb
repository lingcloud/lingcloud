module SQLite3

  module Version

    MAJOR = 1
    MINOR = 2
    TINY  = 4

    STRING = [ MAJOR, MINOR, TINY ].join( "." )
    #:beta-tag:

  end

end
